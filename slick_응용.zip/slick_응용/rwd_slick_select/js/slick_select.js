$(function(){

$('.brand-hero').slick({
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 600,
  arrows: false,
  dots: false,
  fade: true,              // 크로스페이드
  pauseOnHover: false,
  pauseOnFocus: false,
  draggable: false,        // 상단은 스와이프 비활성(선택)
  swipe: false,
  touchMove: false
});

  $('.slider').slick({
        autoplay: true,
        infinity: true,
        slidesToShow:3,
        slidesToScroll:1, 
        dots: true,     
        responsive: [   
                     {
                   breakpoint: 769,
                   settings: {
                     slidesToShow: 2,
                     slidesToScroll: 1
                   }
                 },
                 {
                   breakpoint: 480,
                   settings: {
                     slidesToShow: 1,
                     slidesToScroll: 1
                   }
                 }
           ]     
   });

   $("select.test").on("change",function(){
      const ab=$(this).val();
      slideTarget( ab.substr(4,1) );   

      function slideTarget(n){

      if (n==0) {
        $(".slider").slick("slickUnfilter");
       }else if(n==1){
        $(".slider").slick("slickUnfilter");
             $(".slider").slick("slickFilter", $(".slider li").filter(".Charms"));
        }else if(n==2){
          $(".slider").slick("slickUnfilter");
               $(".slider").slick("slickFilter", $(".slider li").filter(".Rings"));
           }else{
            $(".slider").slick("slickUnfilter");
                $(".slider").slick("slickFilter", $(".slider li").filter(".Necklaces"));
           }
          
      }
   });
});
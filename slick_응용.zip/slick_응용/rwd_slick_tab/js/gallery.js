// /js/filter1.js
$(function () {
  const $items = $("#gallery .gallery-box");
  const tagged = {};

  // 이미지의 data-tags → 태그 맵 구성 (trim 처리)
  $items.each(function () {
    const $img = $(this).find("img");
    const raw = $img.data("tags") || "";
    raw.split(",").forEach((t) => {
      const key = $.trim(t);
      if (!key) return;
      (tagged[key] ||= []).push(this); // this = .gallery-box
    });
  });

  // 초기 상태: "전체" 활성 + 모두 보이기
  $(".gallery-filter .first a").addClass("active");
  $items.show();

  // "전체" 버튼
  $(".gallery-filter .first a").on("click", function (e) {
    e.preventDefault();
    $("#button li").removeClass("active");
    $(this).addClass("active");
    $items.show();
  });

  // 개별 태그 버튼 (한 번만 바인딩)
  $("#button li").not(".first").on("click", function () {
    const key = $.trim($(this).text()); // 공백 제거
    $(".gallery-filter .first a").removeClass("active");
    $(this).addClass("active").siblings().removeClass("active");

    if (tagged[key] && tagged[key].length) {
      $items.hide();
      $(tagged[key]).show();
    } else {
      // 매칭 없으면 전체로 복구(사용자 오타/공백 보호)
      $items.show();
    }
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const navToggle  = document.getElementById('nav-toggle');          // 체크박스
  const menuBtn    = document.querySelector('.menu-btn');            // ☰ 라벨
  const mobileMenu = document.getElementById('mobile-menu');         // 모바일 메뉴
  const overlay    = document.querySelector('.nav-dim');             // 오버레이 라벨
  const closeBtn   = mobileMenu?.querySelector('.close-btn');        // (있다면) X 라벨
  let lastFocused = null;

  const getFocusables = () =>
    mobileMenu?.querySelectorAll('a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])');

  function openMenu() {
    document.body.classList.add('scroll-lock');
    menuBtn?.setAttribute('aria-expanded', 'true');
    mobileMenu?.setAttribute('aria-hidden', 'false');
    lastFocused = document.activeElement;
    const f = getFocusables()?.[0];
    f && f.focus();
  }

  function closeMenu(focusBack = true) {
    if (!navToggle) return;
    navToggle.checked = false; // CSS 토글 해제
    document.body.classList.remove('scroll-lock');
    menuBtn?.setAttribute('aria-expanded', 'false');
    mobileMenu?.setAttribute('aria-hidden', 'true');
    if (focusBack && lastFocused) lastFocused.focus();
  }

  // 체크박스 상태 변화 감지 → 열기/닫기 상태 동기화
  navToggle?.addEventListener('change', () => {
    if (navToggle.checked) openMenu(); else closeMenu(false);
  });

  // 메뉴 내 링크 클릭 시 자동 닫기 (앵커 이동은 그대로 진행)
  mobileMenu?.addEventListener('click', (e) => {
    const t = e.target;
    if (t instanceof Element && t.matches('a[href]')) closeMenu();
  });

  // ESC 닫기 + 포커스 트랩
  document.addEventListener('keydown', (e) => {
    if (!navToggle?.checked || !mobileMenu) return;

    if (e.key === 'Escape') {
      e.preventDefault();
      closeMenu();
    }

    if (e.key === 'Tab') {
      const list = Array.from(getFocusables() || []);
      if (!list.length) return;
      const first = list[0];
      const last  = list[list.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault(); last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault(); first.focus();
      }
    }
  });

  // 데스크톱으로 리사이즈되면 강제 닫기 (브레이크포인트는 프로젝트 값에 맞춰 조정)
  const MQ = window.matchMedia('(min-width: 1024px)');
  MQ.addEventListener?.('change', (e) => { if (e.matches) closeMenu(false); });

  // (선택) X 버튼 라벨이 있다면 누를 때 포커스 복귀

});

